int main() {
	int x = 5;
	int y = -10;
	int z = y / x;
	return 0;
}
