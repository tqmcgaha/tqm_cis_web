Here is the source code that I have for the lcc-1.3 compiler.

The build model for this code is pretty primitive. The compiler suite is
actually composed of a set of executables: cpp, lc3pp, lcc and rcc. You
have to build the all and then make sure that they are *all* in the path
for the stupid thing to work. I ended up monkeying with the source so
that the tools assume that all of the executables are in the current
directory. This means that the students put all of the executables and
all of their code in one directory and ran the compilation. This is
clearly less than ideal but it was a simple model that worked across all
of the platforms we wanted to support, Mac, Linux and Windows.

It would be nice if someone could take a closer look at this and see if
there is a better solution. Amir was making noises about rewriting the
whole thing using llvm but I find it hard to believe that anyone would
muster the courage to take that on. May be a nice student summer project
though.

All the best.

