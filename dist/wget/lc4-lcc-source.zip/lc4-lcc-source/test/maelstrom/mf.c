#include "lc3-stdlib.h"

struct mblock_t 
{
  struct mblock_t *fnext;
  unsigned int f_allocated;
  unsigned int size;
};

static struct mblock_t *flist;

void lc3_sbrk(void *base, unsigned int size)
{
  flist = (struct mblock_t *)base;
  flist->fnext = NULL;
  flist->f_allocated = FALSE;
  flist->size = size - sizeof(struct mblock_t);
}

void *lc3_malloc(unsigned int size)
{
  struct mblock_t *prev, *curr;

  for (prev = NULL, curr = flist; curr; prev = curr, curr = curr->fnext)
    {
      /* Not big enough */
      if (curr->size < size)
	continue;

      /* If there are enough for two of these in the current block, chop it in half */ 
      else if (curr->size > ((2 * size) + sizeof(struct mblock_t)))
	{
	  struct mblock_t *newcurr = (struct mblock_t *)((char *)curr + sizeof(struct mblock_t) + size);
	  newcurr->fnext = curr->fnext;
	  newcurr->f_allocated = FALSE;
	  newcurr->size = curr->size - sizeof(struct mblock_t) - size;

	  if (prev != NULL) 
	    prev->fnext = newcurr;
	  else 
	    flist = newcurr;

	  curr->fnext = NULL; 
	  curr->f_allocated = TRUE;
	  curr->size = size;
	  return (char *)curr + sizeof(struct mblock_t);
	}
      /* Not enough for two, don't split */ 
      else 
	{
	  if (prev != NULL) 
	    prev->fnext = curr->fnext;
	  else
	    flist = curr->fnext;

	  curr->f_allocated = TRUE;
	  return (char *)curr + sizeof(struct mblock_t);
	}
    }
  /* Out of memory */
  return NULL;
}


void lc3_free (void *block)
{
  struct mblock_t *mblock = (struct mblock_t *)((char*)block - sizeof(struct mblock_t));
  struct mblock_t *prev, *curr;
  unsigned int f_fused = FALSE;

  /* Keeping the block list ordered will help fuse freed blocks */
  for (prev = NULL, curr = flist; curr; prev = curr, curr = curr->fnext)
    if (curr > mblock)
      break;
  
  /* Fuse to next block */
  if (curr && curr == (struct mblock_t *)((char *)mblock + sizeof(struct mblock_t) + mblock->size))
    {
      if (prev != NULL)
	prev->fnext = mblock;
      else
	flist = mblock;

      mblock->fnext = curr->fnext;
      mblock->f_allocated = FALSE;
      mblock->size += sizeof(struct mblock_t) + curr->size;
      
      curr->fnext = NULL;
      curr->size = 0;
      f_fused = TRUE;
    }

  if (prev && (struct mblock_t *)((char *)prev + sizeof(struct mblock_t) + prev->size) == mblock) 
    {
      prev->size += sizeof(struct mblock_t) + mblock->size;
      mblock->fnext = NULL;
      mblock->f_allocated = FALSE;
      mblock->size = 0;
      f_fused = TRUE;
    }

 if (!f_fused)
    {
      mblock->fnext = curr;
      mblock->f_allocated = FALSE;
      if (prev != NULL) 
	prev->fnext = mblock;
      else 
	flist = mblock;
    }
}
