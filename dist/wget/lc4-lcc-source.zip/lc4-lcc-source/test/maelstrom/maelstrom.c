#include "lc3-stdlib.h"

#define V_MAX 4

const lc3int t2vx[8] = {/* 0 */1, /* 45 */1, /* 90 */0, /* 135 */-1, /* 180 */-1, /* 225 */-1, /* 270 */0, /* 315 */1};
const lc3int t2vy[8] = {/* 0 */0, /* 45 */-1, /* 90 */-1, /* 135 */-1, /* 180 */0, /* 225 */1, /* 270 */1, /* 315 */1};

struct bullet_t {
  struct bullet_t *next; 
  lc3int x,y; // position
  lc3int vx,vy; // velocity 
};

struct asteroid_t {
  lc3int x,y;  // position 
  lc3int vx,vy; // velocity
  lc3int size;
};

struct ship_t {
  lc3int x,y,t;
  lc3int vx,vy,vt;
};

static struct ship_t ship;

static struct bullet_t *bullets = NULL;

/*
  0110 -> 6
  1111 -> F
  1111 -> F
  0110 -> 6
*/
const lc3uint small_boulder_bmp = 0x6FF6U;
/* 
   0000 0000 -> 0 0
   0011 1100 -> 3 C
   0111 1110 -> 7 E
   0111 1110 -> 7 E
   
   0111 1110 -> 7 E
   0111 1110 -> 7 E
   0011 1100 -> 3 C 
   0000 0000 -> 0 0
*/
const lc3uint medium_boulder_bmps[4] = {0x0377U, 0x0CEEU, 0x7730U, 0xEEC0U};
/* 
   0011 1100 -> 3 C
   0111 1110 -> 7 E
   1111 1111 -> F F
   1111 1111 -> F F
   
   1111 1111 -> F F
   1111 1111 -> F F
   0111 1110 -> 7 E
   0011 1100 -> 3 C 
*/
const lc3uint large_boulder_bmps[4] = {0x37FFU, 0xCEFFU, 0xFF73U, 0xFFECU};
/* same as medium boulder */
const lc3uint ship_bmps[4] = {0x0377U, 0x0CEEU, 0x7730U, 0xEEC0U};

const lc3uint gun_bmps[8][4] = {
/* 
   0000 0000 -> 0 0
   0000 0000 -> 0 0
   0000 0000 -> 0 0
   0000 1110 -> 0 7
   
   0000 1110 -> 0 7
   0000 0000 -> 0 0
   0000 0000 -> 0 0
   0000 0000 -> 0 0
*/
  {0x0000U, 0x0007U, 0x0000U, 0x0007U},
/* 
   0000 0000 -> 0 0
   0000 0100 -> 0 4
   0000 1110 -> 0 E
   0000 1100 -> 0 C
   
   0000 0000 -> 0 0
   0000 0000 -> 0 0
   0000 0000 -> 0 0
   0000 0000 -> 0 0
*/
  {0x0000U, 0x04ECU, 0x0000U, 0x0000U},
/* 
   0000 0000 -> 0 0
   0001 1000 -> 1 8
   0001 1000 -> 1 8
   0001 1000 -> 1 8
   
   0000 0000 -> 0 0
   0000 0000 -> 0 0
   0000 0000 -> 0 0
   0000 0000 -> 0 0
*/
  {0x0111U, 0x0888U, 0x0000U, 0x0000U},
  {0x0273U, 0x0000U, 0x0000U, 0x0000U},
  {0x0007U, 0x0000U, 0x7000U, 0x0000U},
  {0x3720U, 0x0000U, 0x0000U, 0x0000U},
  {0x0000U, 0x0000U, 0x1110U, 0x8880U},
  {0x0000U, 0x0000U, 0x0000U, 0xCE40U}};


void draw_4x4_centered(lc3int cx, lc3int cy, lc3uint color, lc3uint bmp)
{
  lc3int lx = cx-2;
  lc3int uy = cy-2; 
  if (lx < 0) lx += X_MAX;
  if (uy < 0) uy += Y_MAX;

  draw_4x4_wrapped(lx, uy, color, bmp);
}

void draw_8x8_centered(lc3int cx, lc3int cy, lc3uint color, const lc3uint bmps[4])
{
  lc3int lx = cx-2;
  lc3int uy = cy-2; 
  if (lx < 0) lx += X_MAX;
  if (uy < 0) uy += Y_MAX;

  if (bmps[0] != 0) draw_4x4_wrapped(lx, uy, color, bmps[0]);
  if (bmps[1] != 0) draw_4x4_wrapped(cx, uy, color, bmps[1]);
  if (bmps[2] != 0) draw_4x4_wrapped(lx, cy, color, bmps[2]);
  if (bmps[3] != 0) draw_4x4_wrapped(cx, cy, color, bmps[3]);
} 

void init_ship(void)
{
  ship.x = X_MAX >> 1; ship.y = Y_MAX >> 1;
  ship.vx = ship.vy = 0;
  ship.t = 0;
  ship.vt = 0; 
}

void tick_ship(void)
{
  draw_8x8_centered(ship.x, ship.y, BLACK, ship_bmps);
  ship.x += ship.vx;
  ship.y += ship.vy;
  ship.t = (ship.t + ship.vt + 8) & 7;
  draw_8x8_centered(ship.x, ship.y, WHITE, ship_bmps);
  draw_8x8_centered(ship.x, ship.y, RED, gun_bmps[ship.t]);
}

void tick_bullets(void)
{
  struct bullet_t *b, *pb;
  for (pb = NULL, b = bullets; b; pb = b, b = b->next)
    {
      draw_1(b->x, b->y, BLACK);
      b->x += b->vx;
      b->y += b->vy;
      if (b->x < 0 || b->x > X_MAX || b->y < 0 || b->y > Y_MAX) {
	if (!pb) bullets = b->next;
	else pb->next = b->next;
	lc3_free(b);
      }
      else {
	draw_1(b->x, b->y, RED);
      }
    }
}
  
void tick_asteroids(void)
{
}

void fire(void)
{
  struct bullet_t *b = (struct bullet_t*) lc3_malloc (sizeof(struct bullet_t));
  b->next = bullets;
  bullets = b;

  b->x = 2 * t2vx[ship.t] + ship.x; 
  b->y = 2 * t2vy[ship.t] + ship.y;
  b->vx = 2 * t2vx[ship.t] + ship.vx;
  b->vy = 2 * t2vy[ship.t] + ship.vy;
}

void rotate_right(void)
{
  ship.vt--;
  if (ship.vt < -1) ship.vt = -1;
}

void rotate_left(void)
{
  ship.vt++; 
  if (ship.vt > 1) ship.vt = 1;
}

void thrust(void)
{
  ship.vx += t2vx[ship.t]; 
  ship.vy += t2vy[ship.t];

  if (ship.vx > V_MAX) ship.vx = V_MAX;
  else if (ship.vx < -V_MAX) ship.vx = -V_MAX;
  
  if (ship.vy > V_MAX) ship.vx = V_MAX;
  else if (ship.vy < -V_MAX) ship.vx = -V_MAX;
}

int
main(int argc, char **argv)
{
  init_ship();
  while (1)
    {
      lc3int event = get_event();
      // timer event -> time step
      if (event == 0) {
	tick_ship();
	tick_bullets();
	tick_asteroids();
      }
      else if (event == 'j' || event == 'J') {
	rotate_left();
      }
      else if (event == 'l' || event == 'L') {
	rotate_right();
      }
      else if (event == 'k' || event == 'K') {
	thrust();
      }
      else if (event == ' ') {
	fire();
      }
      else if (event == 'q' || event == 'Q') {
	break;
      }
    }

  return 0;
}

