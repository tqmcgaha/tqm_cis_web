typedef short lc3int; 
typedef unsigned short lc3uint;

#define X_MAX 128
#define Y_MAX 124

#define TRUE 1
#define FALSE 0

#define NULL (void*)0

#define BLACK  0x0000U
#define WHITE  0xFFFFU
#define YELLOW 0x7FF0U
#define RED    0xF000U
#define CYAN   0x0770U

/* Initializes the dynamic memory allocator's "arena".  There is no
   equivalent stdlib function, although _sbrk syscall does do some of
   this. */
void lc3_sbrk(void *base, unsigned int size);

/* Analog of stdlib's malloc */
void *lc3_malloc(unsigned int size);

/* Analog of stdlib's free */
void lc3_free (void *block);

void draw_1(lc3int x, lc3int y, lc3uint color);
void draw_4x4(lc3int x, lc3int y, lc3uint color, lc3uint bmp);
void draw_4x4_wrapped(lc3int x, lc3int y, lc3uint color, lc3uint bmp);
lc3int get_event();
