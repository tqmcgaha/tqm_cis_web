#include "lc4stdlib.h"

const lc4uint p_bmp = 0xF9F8U;

lc4uint missile_counter = 0;
lc4uint timer_counter = 0;

int
main(int argc, char **argv)
{
  lc4_draw_4x4_wrapped(10, 10, RED, p_bmp);
  lc4_draw_4x4_wrapped(100, 100, RED, p_bmp);
  lc4_draw_4x4_wrapped(126, 50, RED, p_bmp);
  lc4_draw_4x4_wrapped(50, 122, RED, p_bmp);
  lc4_draw_4x4_wrapped(127, 123, RED, p_bmp);

  lc4_puts((lc4uint*)"HARNESS 2009\n");
  while(1){
    lc4uint event = lc4_get_event();
    
    if(event == 0){
      if (timer_counter < 3) {
	timer_counter++;
	lc4_puts((lc4uint*)"timer\n");
      }
    } else if (event == 'i' || event == 'j' || event == 'k' || event == 'l'){
      lc4_puts((lc4uint*)"move crosshairs small\n");
    } else if (event == 'I' || event == 'J' || event == 'K' || event == 'L'){
      lc4_puts((lc4uint*)"move crosshairs large\n");
    } else if(event == ' '){
      if (missile_counter == 10) {
	lc4_puts((lc4uint*)"out of missiles\n");
	break;
      } else {
	lc4uint str[32];
	missile_counter++;
	lc4_puts((lc4uint*)"fire: missile #");
	lc4_utoa(missile_counter, str, 32);
	lc4_puts((lc4uint*)str);
	lc4_puts((lc4uint*)"\n");
      }
    }
  }
  return 0;
}
