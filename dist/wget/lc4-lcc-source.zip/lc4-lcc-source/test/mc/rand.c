#include "stdlib.h"
#include "stdio.h"

int main(int argc, char **argv)
{
  int i;
  for (i = 0; i < 256; i++)
    printf("0x%04XU%s", rand() & 0xFFFF, i < 255 ? ", " : "");
  printf("\n");
  return 0;
}
