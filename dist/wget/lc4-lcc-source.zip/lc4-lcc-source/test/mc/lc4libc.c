#ifdef NATIVE
#include "assert.h"
#endif /* NATIVE */
#include "lc4stdlib.h"

lc4uint 
lc4_rand_power2(lc4uint max)
{
  static lc4uint rands[256] = {
#include "rand.asm"
  };

static lc4uint rand_idx = 0;
 
 lc4uint r = ((rands[rand_idx] & (max - 1)) + max) & (max - 1);
  rand_idx = (rand_idx + 1) & 255;
  return r; 
}
