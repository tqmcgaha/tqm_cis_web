#ifdef NATIVE_MODE
typedef int lc4int; 
typedef unsigned int lc4uint;
#else /* !NATIVE_MODE */
typedef short lc4int; 
typedef unsigned short lc4uint;
#endif /* !NATIVE_MODE */

#define MAX_X 128
#define MAX_Y 124

#define TRUE 1
#define FALSE 0

#define NULL (void*)0

#define BLACK  0x0000U
#define WHITE  0xFFFFU
#define YELLOW 0x7FF0U
#define RED    0x7C00U
#define ORANGE 0xF600U
#define BLUE   0x0033U
#define GREEN  0x3300U
#define CYAN   0x0770U

/* Initializes the dynamic memory allocator's "arena".  There is no
   equivalent stdlib function, although _sbrk syscall does do some of
   this. */
void lc4_sbrk(void *base, lc4uint size);
void *lc4_malloc(lc4uint size);
void lc4_free (void *block);

lc4uint lc4_rand_power2(lc4uint max);

void lc4_utoa(lc4uint u, lc4uint *str, lc4uint size);

void lc4_draw_1(lc4int x, lc4int y, lc4uint color);
void lc4_draw_4x4(lc4int x, lc4int y, lc4uint color, lc4uint bmp);
void lc4_draw_4x4_wrapped(lc4int x, lc4int y, lc4uint color, lc4uint bmp);
lc4int lc4_get_event();
void lc4_puts(lc4uint *str);
