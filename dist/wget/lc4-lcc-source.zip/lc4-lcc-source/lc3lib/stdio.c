

void lc3_sprintf(char *s, const char *fmt, ...)
{
  
}

void lc3_
